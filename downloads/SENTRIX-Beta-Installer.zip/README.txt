SENTRIX Beta Installer

Recommended install:
1. Extract the ZIP.
2. Run "Install SENTRIX Beta.cmd".
3. If Windows says the .NET 8 Desktop Runtime is missing, install it from the Microsoft page that opens, then run the installer again.

Alternative install:
- If the .NET 8 Desktop Runtime is already installed, you can run "SENTRIX Beta Setup.exe".

What the installer does:
- Installs SENTRIX Beta to %LOCALAPPDATA%\Programs\SENTRIX Beta.
- Creates a desktop shortcut.
- Creates Start Menu shortcuts.
- Registers an uninstall entry in Windows Apps settings for the current user.

Note:
Windows SmartScreen may warn about unknown publishers until the app is code-signed with a trusted certificate.

Important Before Sharing Widely:
- Code-sign the installer if you can. Unsigned Windows apps can show SmartScreen warnings.
- Add a privacy policy if you collect any data. This app should not upload user files.
- Keep the SHA-256 hash on the page updated whenever you rebuild the installer ZIP.
- Only claim features the app actually has.
