$ErrorActionPreference = "Stop"

$appName = "SENTRIX Beta"
$exeName = "SENTRIX Beta.exe"
$runtimeUrl = "https://dotnet.microsoft.com/en-us/download/dotnet/8.0"
$sourceZip = Join-Path $PSScriptRoot "sentrix-app.zip"
$installRoot = Join-Path $env:LOCALAPPDATA "Programs\$appName"
$appExe = Join-Path $installRoot $exeName
$iconPath = Join-Path $installRoot "Assets\guardian-white-dark-rounded.ico"
$desktopShortcut = Join-Path ([Environment]::GetFolderPath("DesktopDirectory")) "$appName.lnk"
$startMenuFolder = Join-Path ([Environment]::GetFolderPath("StartMenu")) "Programs\$appName"
$uninstallScript = Join-Path $installRoot "Uninstall $appName.cmd"
$uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SENTRIXBeta"

function Show-Message([string]$text, [string]$title = "$appName Setup", [int]$type = 64) {
    $shell = New-Object -ComObject WScript.Shell
    $null = $shell.Popup($text, 0, $title, $type)
}

function Test-DesktopRuntime {
    try {
        $runtimes = & dotnet --list-runtimes 2>$null
        return ($runtimes -match "^Microsoft\.WindowsDesktop\.App 8\.").Count -gt 0
    }
    catch {
        return $false
    }
}

function New-Shortcut([string]$path, [string]$target, [string]$workingDirectory, [string]$icon, [string]$description, [string]$arguments = "") {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($path)
    $shortcut.TargetPath = $target
    $shortcut.Arguments = $arguments
    $shortcut.WorkingDirectory = $workingDirectory
    $shortcut.IconLocation = "$icon,0"
    $shortcut.Description = $description
    $shortcut.Save()
}

if (-not (Test-Path -LiteralPath $sourceZip)) {
    Show-Message "The installer package is missing sentrix-app.zip. Download the full installer again." "$appName Setup" 16
    exit 1
}

if (-not (Test-DesktopRuntime)) {
    Show-Message "$appName needs the Microsoft .NET 8 Desktop Runtime. The download page will open now. Install it, then run this setup again." "$appName Setup" 48
    Start-Process $runtimeUrl
    exit 2
}

Get-Process -Name $appName -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
Expand-Archive -LiteralPath $sourceZip -DestinationPath $installRoot -Force

New-Item -ItemType Directory -Force -Path $startMenuFolder | Out-Null
New-Shortcut $desktopShortcut $appExe $installRoot $iconPath $appName
New-Shortcut (Join-Path $startMenuFolder "$appName.lnk") $appExe $installRoot $iconPath $appName
New-Shortcut (Join-Path $startMenuFolder "Uninstall $appName.lnk") "cmd.exe" $installRoot $iconPath "Uninstall $appName" "/c `"$uninstallScript`""

@"
@echo off
taskkill /IM "$exeName" /F >nul 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\SENTRIXBeta" /f >nul 2>nul
del "$desktopShortcut" >nul 2>nul
rmdir /s /q "$startMenuFolder" >nul 2>nul
cd /d "%TEMP%"
rmdir /s /q "$installRoot" >nul 2>nul
"@ | Set-Content -LiteralPath $uninstallScript -Encoding ASCII

New-Item -Path $uninstallKey -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayName" -Value $appName -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayVersion" -Value "Beta" -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "Publisher" -Value "SENTRIX" -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "InstallLocation" -Value $installRoot -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayIcon" -Value $iconPath -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "UninstallString" -Value "cmd.exe /c `"$uninstallScript`"" -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "QuietUninstallString" -Value "cmd.exe /c `"$uninstallScript`"" -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "NoModify" -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "NoRepair" -Value 1 -PropertyType DWord -Force | Out-Null

$answer = (New-Object -ComObject WScript.Shell).Popup("$appName installed successfully. Launch it now?", 0, "$appName Setup", 68)
if ($answer -eq 6) {
    Start-Process -FilePath $appExe -WorkingDirectory $installRoot
}
